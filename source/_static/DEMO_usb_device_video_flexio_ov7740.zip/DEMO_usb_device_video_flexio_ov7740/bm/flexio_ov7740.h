/*
 * Copyright (c) 2015, Freescale Semiconductor, Inc.
 * Copyright (c) 2016, Telecom Design, SA.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 * o Redistributions of source code must retain the above copyright notice, this list
 *   of conditions and the following disclaimer.
 *
 * o Redistributions in binary form must reproduce the above copyright notice, this
 *   list of conditions and the following disclaimer in the documentation and/or
 *   other materials provided with the distribution.
 *
 * o Neither the name of Freescale Semiconductor, Inc. nor the names of its
 *   contributors may be used to endorse or promote products derived from this
 *   software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#ifndef __FLEXIO_OV7740_H__
#define __FLEXIO_OV7740_H__

/*******************************************************************************
 * Definitions
 ******************************************************************************/

#define FLEXIO_DMA_CHANNEL (17U)

#define OV7740_BYTES_PER_PIXEL 2U
#define OV7740_HORIZONTAL_POINTS 160U
#define OV7740_VERTICAL_POINTS 120U
#define OV7740_FRAME_PIXELS (OV7740_HORIZONTAL_POINTS * OV7740_VERTICAL_POINTS)
#define OV7740_FRAME_BYTES (OV7740_FRAME_PIXELS * OV7740_BYTES_PER_PIXEL)
#define LCD_HORIZONTAL_START_POINT ((SCREEN_SIZE_LONGER_SIDE - OV7740_HORIZONTAL_POINTS) >> 1)
#define LCD_VERTICAL_START_POINT ((SCREEN_SIZE_SHORTER_SIDE - OV7740_VERTICAL_POINTS) >> 1)
#define LCD_HORIZONTAL_END_POINT (LCD_HORIZONTAL_START_POINT + OV7740_HORIZONTAL_POINTS - 1)
#define LCD_VERTICAL_END_POINT (LCD_VERTICAL_START_POINT + OV7740_VERTICAL_POINTS - 1)



/*******************************************************************************
 * API
 ******************************************************************************/

void FLEXIO_Ov7740Init(void);
void FLEXIO_Ov7740StartCapture(uint8_t bufferIndex);
void FLEXIO_Ov7740AsynCallback(void);

#endif /* __FLEXIO_OV7740_H__ */
