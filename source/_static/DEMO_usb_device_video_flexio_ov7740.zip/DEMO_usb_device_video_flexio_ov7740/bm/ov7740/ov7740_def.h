///*
// * Copyright (c) 2015, Freescale Semiconductor, Inc.
// * Copyright (c) 2016, Telecom Design, SA.
// * All rights reserved.
// *
// * Redistribution and use in source and binary forms, with or without modification,
// * are permitted provided that the following conditions are met:
// *
// * o Redistributions of source code must retain the above copyright notice, this list
// *   of conditions and the following disclaimer.
// *
// * o Redistributions in binary form must reproduce the above copyright notice, this
// *   list of conditions and the following disclaimer in the documentation and/or
// *   other materials provided with the distribution.
// *
// * o Neither the name of Freescale Semiconductor, Inc. nor the names of its
// *   contributors may be used to endorse or promote products derived from this
// *   software without specific prior written permission.
// *
// * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
// * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
// * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
// * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
// * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
// * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
// * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
// * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
// * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
// */
//
//#ifndef _OV7740_DEF_H_
//#define _OV7740_DEF_H_
//
///*!
// * @addtogroup ov7740
// * @{
// */
//
///*******************************************************************************
// * Definitions
// ******************************************************************************/
//
///*! @brief Register definitions for the OV7740.*/
#define OV7740_PID_REG 0x0AU /*!< Product ID MSB register address. */
#define OV7740_PID_NUM 0x77U /*!< Product ID. */

#define OV7740_VER_REG 0x0BU /*!< Product ID LSB register address. */
#define OV7740_VER_NUM 0x42U /*!< Product VERION. */

#define OV7740_REG2_REG 0x12U        /*!< Control 7. */
#define OV7740_REG12_RESET_MASK 0x80U /*!< Register reset. */
///*! @} */
//
//#endif /*_OV7740_DEF_H_*/
