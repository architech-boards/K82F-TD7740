/*
 * Copyright (c) 2015, Freescale Semiconductor, Inc.
 * Copyright (c) 2016, Telecom Design, SA.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 * o Redistributions of source code must retain the above copyright notice, this list
 *   of conditions and the following disclaimer.
 *
 * o Redistributions in binary form must reproduce the above copyright notice, this
 *   list of conditions and the following disclaimer in the documentation and/or
 *   other materials provided with the distribution.
 *
 * o Neither the name of Freescale Semiconductor, Inc. nor the names of its
 *   contributors may be used to endorse or promote products derived from this
 *   software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#ifndef _OV7740_DRIVER_H_
#define _OV7740_DRIVER_H_

#include "fsl_common.h"
#include "fsl_i2c.h"
#include "ov7740_def.h"

/*******************************************************************************
 * Definitions
 ******************************************************************************/
/*! @brief OV7740 I2C address. */
#define OV7740_I2C_ADDR 0x21U
#define OV7740_I2C_BAUDRATE 100U
#define OV7740_I2C_TIMEOUT_MS 500U
#define OV7740_I2C_CLK_SRC kCLOCK_CoreSysClk

/*!
 * @addtogroup ov7740
 * @{
 */

/*! @brief I2C command structure                                               */
typedef struct ov7740_I2C_command
{
    uint8_t reg;
    uint8_t val;
} ov7740_I2C_command_t;
/*! end of I2C command structure	*/

/*! @brief ov7740 return status. */
typedef enum _ov7740_status
{
    kStatus_OV7740_Success = 0x0, /*!< success */
    kStatus_OV7740_I2CFail = 0x1, /*!< I2C failure */
    kStatus_OV7740_Fail = 0x2,    /*!< fail */
} ov7740_status_t;

/*! @brief ov7740 handler configuration structure                             */
typedef struct ov7740_handler
{
    /* I2C revelant definition. */
    I2C_Type *i2cBase;     /*!< I2C instance. */
    uint8_t i2cDeviceAddr; /*!< I2C device address */
} ov7740_handler_t;


/*******************************************************************************
 * Constants
 ******************************************************************************/

/*******************************************************************************
 * Global variables
 ******************************************************************************/

/*******************************************************************************
 * API
 ******************************************************************************/
#if defined(__cplusplus)
extern "C" {
#endif

/*!
 * @brief ov7740 initialize function.
 *
 * This function would call ov7740_i2c_init(), and in this function, some configurations
 * are fixed.
 */
ov7740_status_t OV7740_Init(ov7740_handler_t *handle);

/*!
 * @brief Deinit the ov7740 codec. Mainly used to close the I2C controller.
 * @param handle ov7740 handler structure pointer.
 */
ov7740_status_t OV7740_Deinit(ov7740_handler_t *handle);

/*!
 * @brief OV7740 configuration.
 * @param handle #ov7740_handler_t structure.
 */
ov7740_status_t OV7740_Configure(ov7740_handler_t *handle);


#if defined(__cplusplus)
}
#endif

/*! @} */

#endif /*__OV7740_DRIVER_H__ */
