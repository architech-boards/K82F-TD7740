/*
 * Copyright (c) 2015, Freescale Semiconductor, Inc.
 * Copyright (c) 2016, Telecom Design, SA.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 * o Redistributions of source code must retain the above copyright notice, this list
 *   of conditions and the following disclaimer.
 *
 * o Redistributions in binary form must reproduce the above copyright notice, this
 *   list of conditions and the following disclaimer in the documentation and/or
 *   other materials provided with the distribution.
 *
 * o Neither the name of Freescale Semiconductor, Inc. nor the names of its
 *   contributors may be used to endorse or promote products derived from this
 *   software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include "ov7740_driver.h"
#include "fsl_sccb_master_driver.h"

/*******************************************************************************
 * Definitions
 ******************************************************************************/

/*! @brief OV7740 frame rate options                                          */
ov7740_I2C_command_t FPS_30 = {0x11, 0x00};
ov7740_I2C_command_t FPS_15 = {0x11, 0x01};

/*! OV7740 I2C basic initialization commands                                  */
uint8_t nb_commands_I2C_init = 126;
ov7740_I2C_command_t I2C_INNIT_COMMANDS[] = {
		{0x13,0xff},
		{0x55,0x40}, // PLL divider (by 4)
		{0x12,0x00},
		{0xd5,0x10},
		{0x0c,0x12},
		{0x0d,0x34},
		{0x28,0x00},
		//{0x28,0x40}, // HSYNC instead of HREF
		{0x17,0x24},
		//{0x17,0x12}, //AHSTART
		{0x18,0xa0},
		{0x19,0x03},
		//{0xe7,0x03}, //FIFO delay
		//{0xe8,0x80}, //FIFO delay
		{0x1a,0xf0},
		{0x1b,0x85},
		//{0x1b,0x8F},
		{0x1e,0x13},
		{0x22,0x03},
		{0x29,0x17},
		{0x2b,0xf8},
		{0x2c,0x01},
		{0x31,0x28},
		{0x32,0x3c},
		{0x33,0xc4},
		{0x3a,0xb4},
		{0x36,0x3f},
		{0x04,0x60},
		{0x27,0x80},
		{0x3d,0x0f},
		{0x3e,0x82},
		{0x3f,0x40},
		{0x40,0x7f},
		{0x41,0x6a},
		{0x42,0x29},
		{0x44,0xe5},
		{0x45,0x41},
		{0x47,0x42},
		{0x48,0x00},
		{0x49,0x61},
		{0x4a,0xa1},
		{0x4b,0x46},
		{0x4c,0x18},
		{0x4d,0x50},
		{0x4e,0x13},
		{0x64,0x00},
		{0x67,0x88},
		{0x68,0x1a},
		{0x14,0x38},
		{0x24,0x3c},
		{0x25,0x30},
		{0x26,0x72},
		{0x50,0x97},
		{0x51,0x7e},
		{0x52,0x00},
		{0x53,0x00},
		{0x20,0x00},
		{0x21,0x23},
		{0x38,0x11},
		{0xe9,0x00},
		{0x56,0x55},
		{0x57,0xff},
		{0x58,0xff},
		{0x59,0xff},
		{0x5f,0x04},
		{0x13,0xff},
		{0x80,0x7f},
		{0x81,0x3f},
		{0x82,0x3f},
		{0x83,0x03},
		{0x38,0x11},
		{0x84,0x70},
		{0x85,0x00},
		{0x86,0x03},
		{0x87,0x01},
		{0x88,0x05},
		{0x89,0x30},
		{0x8d,0x40},
		{0x8e,0x00},
		{0x8f,0x33},
		{0x93,0x28},
		{0x94,0x20},
		{0x95,0x33},
		{0x99,0x30},
		{0x9a,0x14},
		{0x9b,0x33},
		{0x9c,0x08},
		{0x9d,0x12},
		{0x9e,0x23},
		{0x9f,0x45},
		{0xa0,0x55},
		{0xa1,0x64},
		{0xa2,0x72},
		{0xa3,0x7f},
		{0xa4,0x8b},
		{0xa5,0x95},
		{0xa6,0xa7},
		{0xa7,0xb5},
		{0xa8,0xcb},
		{0xa9,0xdd},
		{0xaa,0xec},
		{0xab,0x1a},
		{0xce,0x78},
		{0xcf,0x6e},
		{0xd0,0x0a},
		{0xd1,0x0c},
		{0xd2,0x84},
		{0xd3,0x90},
		{0xd4,0x1e},
		{0x5a,0x24},
		{0x5b,0x1f},
		{0x5c,0x88},
		{0x5d,0x60},
		{0xac,0x6e},
		{0xbe,0xff},
		{0xbf,0x00},
		{0x70,0x00},
		{0x71,0x34},
		{0x74,0x28},
		{0x75,0x98},
		{0x76,0x00},
		{0x77,0x08},
		{0x78,0x01},
		{0x79,0xc2},
		{0x7d,0x02},
		{0x7a,0x9c},
		{0x7b,0x40},
		{0xec,0x02},
		{0x7c,0x0c},
		{0x69,0x08},
		{0x69,0x00}
};


/*! OV7740 I2C initialization commands for Color Test Pattern Screen                                  */
uint8_t nb_commands_I2C_color_test_pattern_init = 4;
ov7740_I2C_command_t I2C_COLOR_TEST_PATTERN_INNIT_COMMANDS[] = {
		{0x38, 0x17},
		{0x84, 0x12}, //0x12 for animated img, 02 for still img
		{0x38, 0x18},
		{0x84, 0x18}  //0x18 for animated img, 08 for still img
};


/*******************************************************************************
 * Code
 ******************************************************************************/
static volatile uint32_t i2c_state = 0;

static void delay(void)
{
	volatile uint32_t i = 0;
	for (i = 0; i < 1000; ++i)
	{
		/* code */
		__asm("NOP");
	}
}

ov7740_status_t OV7740_Init(ov7740_handler_t *handle)
{
	uint8_t u8TempVal0, u8TempVal1;

	/* Reset Device */
	I2C_Write_OV7740_Reg(handle->i2cBase, handle->i2cDeviceAddr, OV7740_REG2_REG, OV7740_REG12_RESET_MASK);
	/* wait for a least 1ms */
	volatile uint32_t j = 0;
	for (j = 0; j < 20; ++j)
	{
		delay(); /* 5ms */
	}

	/* Read product ID nuumber MSB */
	if (I2C_Read_OV7740_Reg(handle->i2cBase, handle->i2cDeviceAddr, OV7740_PID_REG, &u8TempVal0, 1) !=
			kStatus_OV7740_Success)
	{
		return kStatus_OV7740_Fail;
	}
	/* Read product ID nuumber MSB */
	if (I2C_Read_OV7740_Reg(handle->i2cBase, handle->i2cDeviceAddr, OV7740_VER_REG, &u8TempVal1, 1) !=
			kStatus_OV7740_Success)
	{
		return kStatus_OV7740_Fail;
	}
	if ((u8TempVal0 != OV7740_PID_NUM) && (u8TempVal1 != OV7740_VER_NUM))
	{
		return kStatus_OV7740_Fail;
	}

	/*	Initialize OV7740 with SCCB	*/
	OV7740_Configure(handle);


	// HACK for displaying test pattern
    /*volatile uint32_t i = 0;
    for (i = 0; i < nb_commands_I2C_color_test_pattern_init; ++i)
    {
    	I2C_Write_OV7740_Reg(handle->i2cBase, handle->i2cDeviceAddr, I2C_COLOR_TEST_PATTERN_INNIT_COMMANDS[i].reg, I2C_COLOR_TEST_PATTERN_INNIT_COMMANDS[i].val);
    }*/


	return kStatus_OV7740_Success;
}

ov7740_status_t OV7740_Deinit(ov7740_handler_t *handle)
{
	i2c_state--;
	if (i2c_state == 0)
	{
		I2C_MasterDeinit(handle->i2cBase);
	}
	return kStatus_OV7740_Success;
}

ov7740_status_t OV7740_Configure(ov7740_handler_t *handle)
{
	/* 15FPS */
	I2C_Write_OV7740_Reg(handle->i2cBase, handle->i2cDeviceAddr, FPS_15.reg, FPS_15.val);

	/* 30FPS */
	//I2C_Write_OV7740_Reg(handle->i2cBase, handle->i2cDeviceAddr, FPS_30.reg, FPS_30.val);

	/* Basic initialization commands */
	volatile uint32_t i = 0;
	for (i = 0; i < nb_commands_I2C_init; ++i)
	{
		/*if (  I2C_INNIT_COMMANDS[i].mask != 0xFF ) {
			uint8_t reg;
			reg = I2C_Read_OV7740_Reg
		}*/

		I2C_Write_OV7740_Reg(handle->i2cBase, handle->i2cDeviceAddr, I2C_INNIT_COMMANDS[i].reg, I2C_INNIT_COMMANDS[i].val);
	}

	return kStatus_OV7740_Success;
}
